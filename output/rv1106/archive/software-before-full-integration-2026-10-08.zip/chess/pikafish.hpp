#pragma once

#include <chrono>
#include <csignal>
#include <string>
#include <vector>

// 同步、单实例使用；搜索期间主线程只响应取消，不处理界面或机械臂事件。
class Pikafish {
public:
    Pikafish() = default;
    ~Pikafish() { close(); }
    Pikafish(const Pikafish&) = delete;
    Pikafish& operator=(const Pikafish&) = delete;

    bool start(const char* engineDir);
    bool legalMoves(const std::string& moves, std::vector<std::string>& out);
    bool think(const std::string& moves, int timeMs, std::string& best);
    // 从已确认的任意棋局开始，完整历史让引擎保留回合与重复局面上下文。
    bool legalMoves(const std::string& baseFen, const std::string& moves, std::vector<std::string>& out);
    bool think(const std::string& baseFen, const std::string& moves, int timeMs, std::string& best);
    void close();
    std::string error;
    const volatile sig_atomic_t* cancelled = nullptr;

private:
    using Clock = std::chrono::steady_clock;
    int fd_ = -1;
    int pid_ = -1;
    std::string pending_;
    Clock::time_point deadline_;

    bool fail(const std::string& message);
    bool wait(short events);
    bool send(const std::string& text);
    bool readLine(std::string& line);
    bool position(const std::string& baseFen, const std::string& moves);
};
