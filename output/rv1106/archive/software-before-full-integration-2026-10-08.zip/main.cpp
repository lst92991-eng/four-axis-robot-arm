#include "chess/pikafish.hpp"
#include <algorithm>
#include <cerrno>
#include <csignal>
#include <fcntl.h>
#include <iostream>
#include <poll.h>
#include <string>
#include <unistd.h>
#include <vector>

static volatile sig_atomic_t stopRequested = 0;
static void onStop(int) { stopRequested = 1; }

static bool input(const char* prompt, std::string& text)
{
    std::cout << prompt << std::flush;
    text.clear();
    // 短轮询让等待人输入时也能响应 Ctrl-C，不依赖阻塞 getline 的中断行为。
    while (!stopRequested) {
        pollfd fd{STDIN_FILENO, POLLIN, 0};
        int ready = poll(&fd, 1, 100);
        if (ready < 0) { if (errno == EINTR) continue; return false; }
        if (ready == 0) continue;
        char ch;
        ssize_t size = read(STDIN_FILENO, &ch, 1);
        if (size < 0 && (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)) continue;
        if (size <= 0) return false;
        if (ch == '\n') return text != "quit";
        if (ch == '\r') continue;
        if (text.size() >= 79) { std::cerr << "输入过长，已退出。\n"; return false; }
        text += ch;
    }
    return false;
}

int main(int argc, char* argv[])
{
    if (argc != 2) {
        std::cerr << "用法：scara_chess <皮卡鱼与预解压权重所在目录>\n";
        return 2;
    }
    struct sigaction action{};
    action.sa_handler = onStop;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGINT, &action, nullptr) || sigaction(SIGTERM, &action, nullptr)) return 1;
    // 防止信号恰好清空终端输入后 read 阻塞；所有正常退出路径都恢复原标志。
    struct InputMode {
        int flags = fcntl(STDIN_FILENO, F_GETFL);
        ~InputMode() { if (flags >= 0) fcntl(STDIN_FILENO, F_SETFL, flags); }
    } inputMode;
    if (inputMode.flags < 0 || fcntl(STDIN_FILENO, F_SETFL, inputMode.flags | O_NONBLOCK) < 0) {
        std::cerr << "无法读取标准输入。\n";
        return 1;
    }
    Pikafish engine;
    engine.cancelled = &stopRequested;
    if (!engine.start(argv[1])) {
        std::cerr << engine.error << '\n';
        return stopRequested ? 130 : 1;
    }
    std::cout << "人执红，皮卡鱼执黑。标准开局，输入 e3e4 这样的走法；quit 退出。\n";
    std::string history, move, answer;
    std::vector<std::string> legal;
    // 只保存已确认的走法；完整历史也提供给引擎判断重复局面。
    for (int round = 0; round < 512 && !stopRequested; ++round) {
        if (!engine.legalMoves(history, legal)) break;
        if (legal.empty()) { std::cout << "红方无合法走法，黑方胜。\n"; break; }
        while (true) {
            if (!input("你的走法> ", move)) return stopRequested ? 130 : 0;
            if (std::find(legal.begin(), legal.end(), move) != legal.end()) break;
            std::cout << "走法不合法，棋局未改变，请重新输入。\n";
        }
        if (stopRequested) break;
        history += (history.empty() ? "" : " ") + move;
        std::cout << "已接受红方走法 " << move << '\n';

        if (!engine.legalMoves(history, legal)) break;
        if (legal.empty()) { std::cout << "黑方无合法走法，红方胜。\n"; break; }
        std::cout << "黑方思考中…\n" << std::flush;
        if (!engine.think(history, 1000, move)) break;
        if (std::find(legal.begin(), legal.end(), move) == legal.end()) {
            std::cerr << "引擎结果不在合法走法中，已停止对弈。\n";
            return 1;
        }
        std::cout << "黑方建议走法 " << move << '\n';
        // 终端用 ok 模拟落子完成；以后这里等待机械臂执行成功并经视觉确认。
        while (true) {
            if (!input("确认黑方已落子（ok），失败或退出输入 quit> ", answer)) return stopRequested ? 130 : 0;
            if (answer == "ok") break;
        }
        if (stopRequested) break;
        history += (history.empty() ? "" : " ") + move;
        std::cout << "已确认黑方走法 " << move << '\n';
    }
    if (stopRequested) return 130;
    if (!engine.error.empty()) { std::cerr << engine.error << '\n'; return 1; }
    return 0;
}
