/**
 * @file main.cpp
 * @brief 固定的RV1106/MIS5001单帧实验，按顺序完成读图、校正、判色和保存。
 *
 * 在程序目录运行：读取camera.nv12（1280x960），结果保存到live。
 * capture.sh负责采集、准备live目录和清理旧结果。这里没有命令行选项。
 * 返回0表示分类完成，1表示处理失败，2表示存在不确定棋点。
 */
#include <opencv2/core.hpp>
#include <opencv2/geometry.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/objdetect/aruco_detector.hpp>

#include <cmath>
#include <cstdio>
#include <exception>
#include <fstream>
#include <string>
#include <vector>

// 与当前采集脚本和打印棋盘一致。修改采集分辨率时，需要同时修改脚本。
constexpr int kCameraWidth = 1280;
constexpr int kCameraHeight = 960;
constexpr int kBoardLines = 15;
constexpr int kBoardImageSize = 820;  // 410mm棋盘，校正图按2px/mm绘制。
constexpr int kGridStart = 60;        // 第一个交点距板边30mm。
constexpr int kGridSpacing = 50;      // 25mm格距；15条线只有14个间距。
constexpr int kSampleRadius = 15;     // 7.5mm，取20mm棋子的内圈。

int main()
{
    try {
        cv::setNumThreads(1);  // OpenCV内部使用单线程，减少板端并行开销。

        // 1. 读取固定格式的一帧，并转换为BGR彩色图。
        // Y区占w*h字节，交错UV区占一半，共1,843,200字节。
        // 这个h*3/2行的单通道Mat只是NV12字节容器，不是普通灰度图。
        const int frameBytes = kCameraWidth * kCameraHeight * 3 / 2;
        cv::Mat nv12(kCameraHeight * 3 / 2, kCameraWidth, CV_8UC1);

        // 打开文件，rb表示按二进制读取。
        std::FILE* file = std::fopen("camera.nv12", "rb");
        if (file == nullptr) {
            return 1;
        }

        // 每次读1字节，共读frameBytes字节，直接放进Mat的数据区。
        const size_t bytesRead = std::fread(nv12.data, 1, frameBytes, file);
        // 再读一次应到文件末尾。用int保存，才能区分0xFF字节和EOF。
        const int nextByte = std::fgetc(file);
        const int readError = std::ferror(file);  // 0表示读取过程没有出错。
        std::fclose(file);

        if (bytesRead != frameBytes || nextByte != EOF || readError != 0) {
            return 1;  // 没读满、多出数据或读取出错，本次都停止处理。
        }

        cv::Mat image;
        cv::cvtColor(nv12, image, cv::COLOR_YUV2BGR_NV12);
        if (!cv::imwrite("live/source.jpg", image)) {
            return 1;
        }

        // 2. 找齐四个定位标记，按ID建立16对角点。
        // ID0/1/2/3分别位于棋盘左上/右上/右下/左下，检测返回顺序不固定。
        cv::aruco::DetectorParameters parameters;
        parameters.cornerRefinementMethod = cv::aruco::CORNER_REFINE_SUBPIX;
        cv::aruco::ArucoDetector detector(
            cv::aruco::getPredefinedDictionary(cv::aruco::DICT_4X4_50), parameters);
        std::vector<int> markerIds;
        std::vector<std::vector<cv::Point2f>> markerCorners;
        detector.detectMarkers(image, markerCorners, markerIds);

        int markerIndex[4] = {-1, -1, -1, -1};
        for (size_t index = 0; index < markerIds.size(); ++index) {
            const int id = markerIds[index];
            if (id < 0 || id > 3) {
                continue;
            }
            if (markerIndex[id] != -1) {
                return 1;  // 指定ID不能重复。
            }
            markerIndex[id] = static_cast<int>(index);
        }

        const cv::Point2f centers[4] = {{20, 20}, {800, 20}, {800, 800}, {20, 800}};
        // 标记黑块为18mm正方形；角点顺序按编码本身的方向，白色留边不算在内。
        const cv::Point2f offsets[4] = {{-18, -18}, {18, -18}, {18, 18}, {-18, 18}};
        std::vector<cv::Point2f> cameraPoints;
        std::vector<cv::Point2f> boardPoints;
        for (int id = 0; id < 4; ++id) {
            if (markerIndex[id] < 0) {
                return 1;
            }
            for (int corner = 0; corner < 4; ++corner) {
                cameraPoints.push_back(markerCorners[markerIndex[id]][corner]);
                boardPoints.push_back(centers[id] + offsets[corner]);
            }
        }

        // 3. 拉正棋盘。外四角须按正方向围成凸四边形，排除错误排列。
        const std::vector<cv::Point2f> outline = {
            cameraPoints[0], cameraPoints[5], cameraPoints[10], cameraPoints[15]
        };
        if (!cv::isContourConvex(outline) || cv::contourArea(outline, true) <= 0) {
            return 1;
        }

        const cv::Mat cameraToBoard = cv::findHomography(cameraPoints, boardPoints, 0);
        if (cameraToBoard.empty() || !cv::checkRange(cameraToBoard)) {
            return 1;
        }

        // 用全部16对点检查是否一致，不能靠丢弃贴错方向的标记继续识别。
        // 4px只是校正图中的初始误差门限，不是相机或机械臂的精度指标。
        std::vector<cv::Point2f> projectedPoints;
        cv::perspectiveTransform(cameraPoints, projectedPoints, cameraToBoard);
        for (size_t index = 0; index < boardPoints.size(); ++index) {
            const double error = cv::norm(projectedPoints[index] - boardPoints[index]);
            if (!std::isfinite(error) || error > 4.0) {
                return 1;
            }
        }

        cv::Mat rectified;
        cv::warpPerspective(image, rectified, cameraToBoard,
                            cv::Size(kBoardImageSize, kBoardImageSize));

        // 同样校正一张有效区域掩码，确认采样区域来自真实图像，而非边界填色。
        // 原图外圈留1px余量，覆盖彩色图双线性插值需要的邻居。
        cv::Mat validPixels = cv::Mat::zeros(image.size(), CV_8UC1);
        validPixels(cv::Rect(1, 1, image.cols - 2, image.rows - 2)).setTo(255);
        cv::Mat validBoard;
        cv::warpPerspective(validPixels, validBoard, cameraToBoard,
                            rectified.size(), cv::INTER_NEAREST);
        const int sampleSpan = (kBoardLines - 1) * kGridSpacing + 2 * kSampleRadius + 1;
        const cv::Rect samplingArea(kGridStart - kSampleRadius, kGridStart - kSampleRadius,
                                    sampleSpan, sampleSpan);
        if (cv::countNonZero(validBoard(samplingArea)) != samplingArea.area()) {
            return 1;
        }

        // 4. 按颜色占比判断棋子。保留彩色，仅把BGR换成更方便判色的HSV。
        cv::Mat hsv;
        cv::Mat blackMask;
        cv::Mat whiteMask;
        cv::Mat backgroundMask;
        cv::cvtColor(rectified, hsv, cv::COLOR_BGR2HSV);
        // 黑：低V；白：低S且高V；底色：黄褐范围。阈值仍需用打印实拍校准。
        cv::inRange(hsv, cv::Scalar(0, 0, 0), cv::Scalar(179, 255, 70), blackMask);
        cv::inRange(hsv, cv::Scalar(0, 0, 180), cv::Scalar(179, 55, 255), whiteMask);
        cv::inRange(hsv, cv::Scalar(8, 65, 90), cv::Scalar(40, 255, 255), backgroundMask);

        // 在14x14个棋格中心各取3x3样本，防止错误底色被当作满盘白子。
        const int gridCells = kBoardLines - 1;
        int backgroundMatches = 0;
        for (int row = 0; row < gridCells; ++row) {
            for (int col = 0; col < gridCells; ++col) {
                const int x = kGridStart + col * kGridSpacing + kGridSpacing / 2;
                const int y = kGridStart + row * kGridSpacing + kGridSpacing / 2;
                backgroundMatches += cv::countNonZero(backgroundMask(cv::Rect(x - 1, y - 1, 3, 3)));
            }
        }
        const bool backgroundKnown = backgroundMatches >= 0.70 * gridCells * gridCells * 9;

        // 这是0/255的选择掩码，不是滤波核。生成一次圆形区域，225个交点共同使用。
        const int diameter = 2 * kSampleRadius + 1;
        cv::Mat sampleMask = cv::Mat::zeros(diameter, diameter, CV_8UC1);
        // 填实心圆；LINE_8保持边缘只有0或255，便于后面用作选择掩码。
        cv::circle(sampleMask, cv::Point(kSampleRadius, kSampleRadius),
                   kSampleRadius, cv::Scalar(255), cv::FILLED, cv::LINE_8);

        char board[kBoardLines][kBoardLines] = {};
        bool hasUnknown = false;
        for (int row = 0; row < kBoardLines; ++row) {
            for (int col = 0; col < kBoardLines; ++col) {
                const int x = kGridStart + col * kGridSpacing;
                const int y = kGridStart + row * kGridSpacing;
                const cv::Rect sample(x - kSampleRadius, y - kSampleRadius, diameter, diameter);
                // 二值图圆内均值/255就是颜色像素占比，并非识别正确率。
                const double black = cv::mean(blackMask(sample), sampleMask)[0] / 255.0;
                const double white = cv::mean(whiteMask(sample), sampleMask)[0] / 255.0;
                const double background = cv::mean(backgroundMask(sample), sampleMask)[0] / 255.0;

                char state = '?';
                if (backgroundKnown) {
                    if (black >= 0.70 && white <= 0.15) {
                        state = 'B';
                    } else if (white >= 0.70 && black <= 0.15) {
                        state = 'W';
                    } else if (background >= 0.60 && black <= 0.28 && white <= 0.15) {
                        state = '.';
                    }
                }
                board[row][col] = state;
                if (state == '?') {
                    hasUnknown = true;
                }
            }
        }

        // 5. 识别结束后再画标注，避免图形和文字污染判色数据。
        // 统一使用绿色；B/W/./?字符已经表达了每个交点的状态。
        cv::Mat annotated = rectified.clone();
        const cv::Scalar color(40, 170, 40);
        for (int row = 0; row < kBoardLines; ++row) {
            for (int col = 0; col < kBoardLines; ++col) {
                const char state = board[row][col];
                const cv::Point center(kGridStart + col * kGridSpacing, kGridStart + row * kGridSpacing);
                cv::circle(annotated, center, kSampleRadius, color, 1, cv::LINE_AA);
                cv::putText(annotated, std::string(1, state), center + cv::Point(-5, 5),
                            cv::FONT_HERSHEY_SIMPLEX, 0.45, color, 1, cv::LINE_AA);
            }
        }

        // 6. 保存图像与棋局；正常运行不打印过程日志，直接查看结果文件。
        if (!cv::imwrite("live/rectify.png", rectified) ||
            !cv::imwrite("live/annotated.png", annotated)) {
            return 1;
        }
        std::ofstream csv("live/board.csv");
        for (int row = 0; row < kBoardLines; ++row) {
            for (int col = 0; col < kBoardLines; ++col) {
                if (col != 0) {
                    csv << ',';
                }
                csv << board[row][col];
            }
            csv << '\n';
        }
        csv.close();
        if (csv.fail()) {
            return 1;
        }
        return hasUnknown ? 2 : 0;
    } catch (const std::exception&) {
        return 1;
    }
}
