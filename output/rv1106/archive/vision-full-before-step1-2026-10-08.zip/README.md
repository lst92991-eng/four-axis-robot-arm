# SCARA 下棋项目：先跑通 RV1106 视觉

当前阶段只做摄像头采集、棋盘定位和黑白棋子识别。开发标准是 **C++17 + OpenCV 5.0.0**。已经在用户的 RV1106 / Buildroot 2023.02.6 / MIS5001 板上运行；机械臂运动学、五子棋规则和棋力算法暂不进入本阶段。

## 先准备棋盘与棋子

- 可以先用 [20 mm 纸棋子剪裁页](output/pdf/gomoku-stones-a4.pdf) 做视觉测试。A4共三页，合计113枚黑子、112枚白子；第一页已有黑白各40枚，只打印这一页、先剪各几枚即可。选择实际大小/100%，核对100 mm标尺，沿圆形外轮廓剪裁；普通纸可先贴薄硬卡纸，避免翘曲和透出棋盘底色，不覆亮膜。
- 以后换实体棋子时，选直径 **18～20 mm** 的黑白圆形棋子，表面尽量少反光。纸棋子用于当前视觉实验，机械臂抓取阶段再验证实际棋子和末端工具。
- 优先彩色打印 [A2 单页棋盘](output/pdf/gomoku-board-a2.pdf)，选择 **实际大小 / 100%**，关闭适应纸张、缩小和无边距自动放大。打印后用尺量页面的 100 mm 校验尺，并确认相邻交点间距 25 mm。当前 HSV 阈值使用暖黄褐底色，不要改成黑白打印。
- 没有 A2 打印条件时可用 [A4 六页拼接版](output/pdf/gomoku-board-a4-tiles.pdf)。按三列两行排列，横向重复区域 20 mm，纵向重复区域 10 mm，重叠对齐相同网格再固定。不能把六页缩印到一页。
- 棋盘有效底板 **410×410 mm**，15×15 个交点，交点跨度 350 mm。使用哑光纸并贴平在硬板上；不要让拼接处翘起，不要裁掉四角标记周围的白色区域。
- 相机固定在棋盘上方，先调整位置和高度，让整张棋盘及四个标记同时进入画面，并留少量边距。尽量正对棋盘，使用均匀照明，避免强反光。
- 标记 0 所在角是棋盘左上角；程序借助四个不同 ID 识别方向。坐标从 0 开始，行向下、列向右。完整规格见 [board.json](assets/board/board.json)。

## 已经可以在这块板上执行

程序和独立依赖库已部署到 `/root/scara-vision-v1`。下面命令在 **Windows PowerShell** 中执行，当前 ADB 序列号为 `759dce9b268fd05e`：

```powershell
adb -s 759dce9b268fd05e shell sh /root/scara-vision-v1/capture.sh
adb -s 759dce9b268fd05e pull /root/scara-vision-v1/live ./output/rv1106/live
```

若已经进入 `adb shell`，直接运行：

```sh
sh /root/scara-vision-v1/capture.sh
```

脚本临时加载 MIS5001 和采集链路的必要驱动，使用系统自带 `rkisp_demo`，以 **1280×960 NV12** 抓取一帧；先跳过 30 帧，给曝光和白平衡稳定时间。读取 IQ 文件目录 `/oem/usr/share/iqfiles`，本板实际匹配 `mis5001_CMK-OT2115-PC1_30IRC-F16.json`。采集完成后用 OpenCV 转 BGR、检测标记、透视校正并识别交点。

脚本没有修改开机脚本。重启后再次执行会重新加载必要模块。它也不会调用会同时改网络、启动音频和后台视频服务的完整 `RkLunch.sh`。

结果目录包含：

| 文件 | 用途 |
| --- | --- |
| `source.jpg` | 当前采集的彩色图，输入有效时即保存 |
| `rectify.png` | 820×820 的校正棋盘 |
| `annotated.png` | 带交点采样圈和识别字符的检查图 |
| `board.csv` | 15 行×15 列局面，`.` 空位、`B` 黑子、`W` 白子、`?` 不确定 |

未打印或未将棋盘放入画面时，会提示 `Recognition failed`；仍可看 `source.jpg` 检查相机方向、曝光和清晰度。新采集开始时会清除上次原图和局面，处理失败时也会删除本次不完整的局面文件。

识别退出码为 0（本次没有不确定交点）、1（读取/定位/保存失败）、2（有 `?`，保留诊断结果）；采集超时为 124。旧版板端 ADB 可能不把远端退出码传给 Windows，因此需要检查终端消息和本次输出；调试时可在板端命令后执行 `echo $?`。

## 验证范围

MIS5001 的真实采集链路和 NV12 → BGR 转换已在板上跑通。传感器输入为 SGRBG10 / 2592×1944，ISP 输出本实验需要的 1280×960 NV12，单帧 **1,843,200 字节**。

固定格式版本用十组 NV12 合成输入验证：空盘、黑白混合、旋转、透视、缺标记、不确定棋子、重复 ID、单个标记旋转、交换标记位置和错误底色。正常局面逐格对照，异常输入对照返回值。采集超时和失败清理由隔离的模拟采集器验证。

最新结果见 [fixed-input-test-results.json](output/rv1106/validation/fixed-input-test-results.json)。目录中的旧记录保留此前版本的测试情况，不代表当前还提供那些接口。**打印后的棋盘仍需实拍，调整初始 HSV 阈值。**

## 源码与构建

- [vision/main.cpp](vision/main.cpp)：单文件按六步顺序展开，保留中文教学注释；固定读取 `camera.nv12`，没有命令行参数和过程日志。
- [vision/README.md](vision/README.md)：接口、几何坐标、阈值和错误行为。
- [tools/capture.sh](tools/capture.sh)：本板单次采集，含并发锁和有限超时。
- [tools/camera-mis5001.sh](tools/camera-mis5001.sh)：已核对的临时模块加载。
- [cmake/rv1106.cmake](cmake/rv1106.cmake)：Rockchip GCC8.3 / uClibc 交叉工具链。
- [tools/build-opencv.sh](tools/build-opencv.sh)：构建所需 OpenCV 模块、应用及独立部署目录。
- [assets/board/generate_board.py](assets/board/generate_board.py)：按毫米生成 PDF/SVG/PNG；棋盘几何变化需同步应用常量和验证。

本机已经准备好 WSL `Ubuntu-24.04-D` 的专用缓存 `/home/lst/.cache/scara-vision`。OpenCV 来自官方 **5.0.0**，提交 `40738fb16ceddb5fb3fea747585f7ce6abb0605b`；工具链来自 Luckfox 官方仓库提交 `824b817f889c2cbff1d48fcdb18ab494a68f69d1`，对应工具链 tree `c3fe8cde3c2b3d1322aa620046c89d629bc2b88a`，GCC 8.3.0。源码和第三方构建缓存没有放入本项目生产目录。

后续修改源码后，在本机 PowerShell 重建并重新部署：

```powershell
wsl -d Ubuntu-24.04-D -- bash /mnt/c/Users/lst/Desktop/scara/tools/build-opencv.sh
powershell -ExecutionPolicy Bypass -File .\tools\deploy.ps1
```

最终运行库包含 core、imgproc、imgcodecs、objdetect、geometry，以及自动依赖的 features、flann。只启用当前需要的图片处理，不包含 GUI、DNN、视频编解码框架或训练环境。库位于应用目录的 `lib`，使用启动脚本设置库路径，不替换板上的系统 C/C++ 运行库。

初始开源调研保留在 [research](research/01-开源方案调研-2026-10-08.md)。原始空 `main.cpp` 和 `algorithm` 文件尚未改写，机械臂算法后续单独推进。
