import subprocess
log = open("/tmp/scara-live-preview/stream.log", "wb")
p = subprocess.Popen(["sh", "-x", "/tmp/scara-live-preview/stream.sh"], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
print(p.pid)
