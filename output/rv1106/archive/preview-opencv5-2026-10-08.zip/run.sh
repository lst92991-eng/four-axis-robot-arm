#!/bin/bash
cd /home/st/.cache/scara-live-preview
export DISPLAY=:0
export XAUTHORITY=/run/user/1000/.mutter-Xwaylandauth.TP0OW3
export XDG_RUNTIME_DIR=/run/user/1000
export LD_LIBRARY_PATH=/home/st/.local/opencv-5.0.0/lib
set -o pipefail
nc -d 172.32.0.70 18554 | ./preview5
