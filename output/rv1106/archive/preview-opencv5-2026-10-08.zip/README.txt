Live camera preview using OpenCV 5.0.0 and C++17.
Ubuntu runtime: /home/st/.cache/scara-live-preview/preview5
OpenCV install: /home/st/.local/opencv-5.0.0
Input: 1280x960 tightly packed NV12 over the existing temporary FIFO/TCP transport.
Includes ID0..3 detection, 16-point homography, and local grayscale stone classification.
Board geometry is the current 18mm-marker design; larger future markers need matching geometry updates.
15 synthetic grayscale cases passed. Small/blurred physical markers remain a limitation; full physical-board accuracy is not validated.
The project vision/main.cpp remains the earlier format-conversion lesson.
