// Ubuntu实时识别：读帧 -> 四角ID -> 校正棋盘 -> 判断棋子 -> 显示。
// 使用OpenCV 5.0.0；板端项目仍保留原来的格式转换步骤。
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/geometry.hpp>
#include <opencv2/objdetect/aruco_detector.hpp>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

int main()
{
    // 采集分辨率和stream.sh一致；棋盘校正后为820px，格距50px。
    const int width = 1280, height = 960;
    const int lines = 15, start = 60, spacing = 50;
    const int radius = 27, diameter = 2 * radius + 1;
    cv::setNumThreads(2);
    cv::Mat nv12(height * 3 / 2, width, CV_8UC1);
    cv::Mat bgr, annotated, gray, rectified, boardGray;
    cv::Mat panel(820, 1360, CV_8UC3);
    const std::string window = "SCARA - OpenCV 5.0 - IDs and stones - Esc to close";
    cv::namedWindow(window, cv::WINDOW_NORMAL);
    cv::resizeWindow(window, panel.cols, panel.rows);

    cv::aruco::DetectorParameters parameters;
    parameters.cornerRefinementMethod = cv::aruco::CORNER_REFINE_SUBPIX;
    parameters.adaptiveThreshConstant = 5;  // 实拍打印标记偏灰，调整局部二值化阈值。
    cv::aruco::ArucoDetector detector(
        cv::aruco::getPredefinedDictionary(cv::aruco::DICT_4X4_50), parameters);
    const cv::Point2f centers[4] = {{20,20}, {800,20}, {800,800}, {20,800}};
    const cv::Point2f offsets[4] = {{-18,-18}, {18,-18}, {18,18}, {-18,18}};

    // 中心圆用于看棋子，外环用于看邻近底色。掩掉十字，避免把棋线算成黑子。
    cv::Mat centerMask = cv::Mat::zeros(diameter, diameter, CV_8UC1);
    cv::Mat backgroundMask = centerMask.clone();
    cv::circle(centerMask, {radius,radius}, 14, cv::Scalar(255), cv::FILLED);
    cv::circle(backgroundMask, {radius,radius}, 27, cv::Scalar(255), cv::FILLED);
    cv::circle(backgroundMask, {radius,radius}, 22, cv::Scalar(0), cv::FILLED);
    const cv::Rect horizontal(0, radius - 3, diameter, 7);
    const cv::Rect vertical(radius - 3, 0, 7, diameter);
    centerMask(horizontal).setTo(0);
    centerMask(vertical).setTo(0);
    backgroundMask(horizontal).setTo(0);
    backgroundMask(vertical).setTo(0);

    char board[15][15] = {};
    int frame = 0, blackCount = 0, whiteCount = 0, unknownCount = 0;
    bool boardReady = false;
    const auto started = cv::getTickCount();
    while (std::fread(nv12.data, 1, nv12.total(), stdin) == nv12.total()) {
        // 1. 原始帧转BGR。灰度图只参与识别，彩色原图仍然保留。
        cv::cvtColor(nv12, bgr, cv::COLOR_YUV2BGR_NV12);
        cv::cvtColor(bgr, gray, cv::COLOR_BGR2GRAY);
        annotated = bgr.clone();
        rectified = cv::Mat(820, 820, CV_8UC3, cv::Scalar(30,30,30));

        // 2. ArUco返回顺序不固定，用ID找回左上、右上、右下、左下。
        std::vector<int> ids;
        std::vector<std::vector<cv::Point2f>> corners;
        detector.detectMarkers(gray, corners, ids);
        cv::aruco::drawDetectedMarkers(annotated, corners, ids);
        int index[4] = {-1,-1,-1,-1};
        bool duplicate = false;
        for (size_t i = 0; i < ids.size(); ++i) {
            const int id = ids[i];
            if (id < 0 || id > 3) continue;
            if (index[id] != -1) duplicate = true;
            index[id] = int(i);
        }
        boardReady = !duplicate;
        std::string idStatus;
        for (int id = 0; id < 4; ++id) {
            idStatus += "ID" + std::to_string(id) + (index[id] >= 0 ? ":yes  " : ":--  ");
            if (index[id] < 0) boardReady = false;
        }

        // 3. 四个标记共16个角点，拟合后检查是否贴反或排列不一致。
        cv::Mat transform;
        if (boardReady) {
            std::vector<cv::Point2f> source, target;
            for (int id = 0; id < 4; ++id) {
                for (int corner = 0; corner < 4; ++corner) {
                    source.push_back(corners[index[id]][corner]);
                    target.push_back(centers[id] + offsets[corner]);
                }
            }
            const std::vector<cv::Point2f> outline = {source[0],source[5],source[10],source[15]};
            boardReady = cv::isContourConvex(outline) && cv::contourArea(outline, true) > 0;
            if (boardReady) {
                transform = cv::findHomography(source, target, 0);
                boardReady = !transform.empty() && cv::checkRange(transform);
            }
            if (boardReady) {
                std::vector<cv::Point2f> projected;
                cv::perspectiveTransform(source, projected, transform);
                for (size_t i = 0; i < target.size(); ++i) {
                    const double error = cv::norm(projected[i] - target[i]);
                    if (!std::isfinite(error) || error > 6) boardReady = false;
                }
            }
        }
        if (boardReady) {
            cv::warpPerspective(bgr, rectified, transform, {820,820});
            cv::cvtColor(rectified, boardGray, cv::COLOR_BGR2GRAY);
            // 校正后的采样区必须来自真实画面，不能使用图像外面的黑色填充。
            cv::Mat valid = cv::Mat::zeros(gray.size(), CV_8UC1), warpedValid;
            valid(cv::Rect(1,1,width-2,height-2)).setTo(255);
            cv::warpPerspective(valid, warpedValid, transform, {820,820}, cv::INTER_NEAREST);
            const cv::Rect samples(start-radius, start-radius, 14*spacing+diameter, 14*spacing+diameter);
            boardReady = cv::countNonZero(warpedValid(samples)) == samples.area();
        }

        // 4. 黑白打印时，用相邻底色作参照，不再依赖黄褐色HSV范围。
        blackCount = whiteCount = unknownCount = 0;
        for (int row = 0; row < lines; ++row) {
            for (int col = 0; col < lines; ++col) {
                const cv::Point point(start + col*spacing, start + row*spacing);
                char state = '?';
                if (boardReady) {
                    cv::Mat sample = boardGray(cv::Rect(point.x-radius, point.y-radius, diameter, diameter));
                    cv::Scalar average, deviation;
                    cv::meanStdDev(sample, average, deviation, backgroundMask);
                    const double background = average[0];
                    cv::Mat dark, light, similar;
                    cv::threshold(sample, dark, background-35, 255, cv::THRESH_BINARY_INV);
                    cv::threshold(sample, light, background+25, 255, cv::THRESH_BINARY);
                    cv::inRange(sample, cv::Scalar(background-15), cv::Scalar(background+15), similar);
                    const double black = cv::mean(dark, centerMask)[0] / 255;
                    const double white = cv::mean(light, centerMask)[0] / 255;
                    const double empty = cv::mean(similar, centerMask)[0] / 255;
                    // 背景太亮时白子难以区分；底色不均匀时也先保留问号。
                    if (background >= 65 && background <= 220 && deviation[0] <= 18) {
                        if (black >= 0.80) state = 'B';
                        else if (white >= 0.75) state = 'W';
                        else if (empty >= 0.80 && black < 0.10 && white < 0.10) state = '.';
                    }
                }
                board[row][col] = state;
                if (state == 'B') ++blackCount;
                if (state == 'W') ++whiteCount;
                if (state == '?') ++unknownCount;
                // 原灰度数据已单独保存；在彩色副本上统一画绿色标注。
                if (boardReady) {
                    cv::circle(rectified, point, 14, {0,180,0}, 1, cv::LINE_AA);
                    cv::putText(rectified, std::string(1,state), point+cv::Point(-5,5),
                                cv::FONT_HERSHEY_SIMPLEX, 0.45, {0,180,0}, 1, cv::LINE_AA);
                }
            }
        }

        // 5. 左侧看原图和ID，右侧看校正后的棋局；缺角时不给出上一帧的棋局。
        panel.setTo(cv::Scalar(25,25,25));
        cv::Mat left, right;
        cv::resize(annotated, left, {640,480});
        left.copyTo(panel(cv::Rect(0,45,640,480)));
        if (boardReady) {
            cv::resize(rectified, right, {720,720});
            right.copyTo(panel(cv::Rect(640,45,720,720)));
        }
        cv::putText(panel, "Camera + ArUco IDs", {15,30}, cv::FONT_HERSHEY_SIMPLEX, 0.65, {235,235,235}, 1, cv::LINE_AA);
        cv::putText(panel, "Board: B=black W=white .=empty ?=uncertain", {650,30}, cv::FONT_HERSHEY_SIMPLEX, 0.56, {235,235,235}, 1, cv::LINE_AA);
        cv::putText(panel, idStatus, {15,560}, cv::FONT_HERSHEY_SIMPLEX, 0.58, {100,220,130}, 1, cv::LINE_AA);
        const std::string status = boardReady ? "Board located" : "Waiting for 4 consistent corner markers";
        cv::putText(panel, status, {15,595}, cv::FONT_HERSHEY_SIMPLEX, 0.60, {220,220,220}, 1, cv::LINE_AA);
        const std::string counts = "Black " + std::to_string(blackCount) + "  White " + std::to_string(whiteCount) + "  Uncertain " + std::to_string(unknownCount);
        cv::putText(panel, counts, {15,630}, cv::FONT_HERSHEY_SIMPLEX, 0.60, {220,220,220}, 1, cv::LINE_AA);
        ++frame;
        const double seconds = (cv::getTickCount()-started) / cv::getTickFrequency();
        const std::string label = "OpenCV " + cv::getVersionString() + " | Frame " + std::to_string(frame) + " | " + std::to_string(int(frame/seconds)) + " fps | Esc: close";
        cv::putText(panel, label, {15,800}, cv::FONT_HERSHEY_SIMPLEX, 0.55, {100,220,130}, 1, cv::LINE_AA);
        cv::imshow(window, panel);
        const int key = cv::waitKey(1);
        if (key == 27 || key == 'q') break;
    }

    // 停止后留下最后一帧，便于对照实拍和识别结果。
    if (frame == 0) return 1;
    cv::imwrite("last-source.jpg", bgr);
    cv::imwrite("last-view.png", panel);
    std::ofstream csv("last-board.csv");
    for (int row = 0; row < lines; ++row) {
        for (int col = 0; col < lines; ++col) {
            if (col != 0) csv << ',';
            csv << board[row][col];
        }
        csv << '\n';
    }
    std::ofstream result("last-result.txt");
    result << "OpenCV=" << cv::getVersionString() << "\nlocated=" << boardReady
           << "\nblack=" << blackCount << "\nwhite=" << whiteCount << "\nuncertain=" << unknownCount << '\n';
    cv::destroyAllWindows();
    if (!boardReady) return 1;
    return unknownCount == 0 ? 0 : 2;
}
