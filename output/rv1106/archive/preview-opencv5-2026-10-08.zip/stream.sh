#!/bin/sh
set -e
work=/tmp/scara-live-preview
lock=/tmp/scara-vision-capture.lock
mkdir -p "$work"
mkdir "$lock"
camera=
cleanup() {
    if [ -n "$camera" ]; then kill "$camera" 2>/dev/null || :; fi
    rm -f "$work/frames.nv12"
    rmdir "$lock"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap '' HUP
mkfifo "$work/frames.nv12"
exec 3<> "$work/frames.nv12"
sh /root/scara-vision-v1/camera-mis5001.sh > "$work/camera.log" 2>&1
rkisp_demo --device /dev/video11 --width 1280 --height 960 --format NV12 \
    --count 1000030 --stream-skip 30 --stream-count 1000000 \
    --stream-to "$work/frames.nv12" --rkaiq --iqpath /oem/usr/share/iqfiles --silent \
    >> "$work/camera.log" 2>&1 &
camera=$!
socat -u OPEN:"$work/frames.nv12",rdonly TCP-LISTEN:18554,bind=172.32.0.70,reuseaddr,nodelay
